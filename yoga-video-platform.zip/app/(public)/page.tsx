export default function LandingPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Yoga Video Platform</h1>
      <p className="mt-4">Pratica yoga ovunque, quando vuoi.</p>
    </div>
  );
}
