export default function VideosLoading() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Video</h1>
      <p className="mt-2 text-gray-600">Sto caricando il catalogo…</p>
    </div>
  );
}
