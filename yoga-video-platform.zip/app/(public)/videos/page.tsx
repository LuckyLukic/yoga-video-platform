export default function VideosPage() {
  throw new Error("Test error boundary");
}
