export default function Loading() {
  return (
    <main className="max-w-6xl mx-auto p-6">
      <p className="text-gray-600">Caricamento…</p>
    </main>
  );
}
